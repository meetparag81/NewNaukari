package com_naukari_qa_POM;

import com_naukari_qa_Base.TestBase;

public class HomePage extends TestBase
{

}
